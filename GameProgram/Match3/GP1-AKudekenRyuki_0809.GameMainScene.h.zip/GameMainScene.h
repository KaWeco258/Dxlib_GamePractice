#pragma once
/******************************
*�}�N����`
******************************/


/*****************************
*�^��`
******************************/

/*****************************
*�v���g�^�C�v�錾
******************************/

int GameMainScene_Initialize(void);
void GameMainScene_Update(void);
void GameMainScene_Draw(void);
